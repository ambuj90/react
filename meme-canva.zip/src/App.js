import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Stage, Layer, Image as KonvaImage, Text, Transformer } from 'react-konva';
import useImage from 'use-image';
import { Container, Row, Col, Button, Form, Image } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

// Helper component for Image upload
const ImageUpload = ({ onImageAdd }) => {
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      onImageAdd(reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <Form.Group controlId="formFile" className="mb-3">
      <Form.Label>Upload Image</Form.Label>
      <Form.Control type="file" accept="image/*" onChange={handleFileChange} />
    </Form.Group>
  );
};

const galleryImages = [
  "/meme-template/3.jpg",
  "/meme-template/4.jpg",
  "/meme-template/5.jpg",
];

const CanvasApp = () => {
  const [elements, setElements] = useState([]);  // Store images and text objects
  const [selectedId, setSelectedId] = useState(null);  // To manage selected element
  const [textEdit, setTextEdit] = useState('');  // To hold the current editable text value
  const [fontSize, setFontSize] = useState(24);  // To hold current font size
  const [fontWeight, setFontWeight] = useState('normal');  // To hold current font weight
  const [textColor, setTextColor] = useState('#000000'); // To hold the text color
  const [fontFamily, setFontFamily] = useState('Arial');  // Font family to use
  const [isEditingText, setIsEditingText] = useState(false);  // Track if the user is editing text
  const transformerRef = useRef();  // Reference to the Transformer component
  const stageRef = useRef();  // Reference to the stage

  // Mapping of heading tags to corresponding font sizes
  const headingFontSizes = {
    H1: 32,
    H2: 28,
    H3: 24,
    H4: 20,
    H5: 18,
    H6: 16,
  };

  // Available font families and their respective weights
  const fontFamilies = {
    Arial: ['normal', 'bold', 'bolder', 'lighter'],
    Roboto: ['100', '300', '400', '500', '700', '900'],
    'Times New Roman': ['normal', 'bold'],
  };

  // Handle adding a new text element
  const handleAddText = () => {
    const newText = {
      id: `text${elements.length + 1}`,
      text: 'Editable Text',
      x: 50,
      y: 50,
      fontSize: 24,
      fontWeight: 'normal',
      fontFamily: 'Arial',  // Default font family
      fill: '#000000',
      draggable: true,
      type: 'text',
    };
    setElements([...elements, newText]);
  };

  // Handle adding a new image
  const handleAddImage = (imageUrl) => {
    const newImage = {
      id: `image${elements.length + 1}`,
      src: imageUrl,
      x: 0,
      y: 0,
      width: 150,
      height: 150,
      draggable: true,
      type: 'image',
    };
    setElements([...elements, newImage]);
  };

  // Handle selecting an element (text or image)
  const handleSelect = (e) => {
    const id = e.target.name();
    setSelectedId(id);
    const selectedElement = elements.find((el) => el.id === id);
    if (selectedElement && selectedElement.type === 'text') {
      setTextEdit(selectedElement.text);
      setFontSize(selectedElement.fontSize);
      setFontWeight(selectedElement.fontWeight);
      setFontFamily(selectedElement.fontFamily || 'Arial');
      setTextColor(selectedElement.fill);
    }
  };

  // Handle updating text content
  const handleTextEdit = (e) => {
    setTextEdit(e.target.value);
    setElements((prevElements) =>
      prevElements.map((el) =>
        el.id === selectedId && el.type === 'text'
          ? { ...el, text: e.target.value }
          : el
      )
    );
  };

  // Handle updating font size
  const handleFontSizeChange = (newFontSize) => {
    setFontSize(newFontSize);
    setElements((prevElements) =>
      prevElements.map((el) =>
        el.id === selectedId && el.type === 'text'
          ? { ...el, fontSize: newFontSize }
          : el
      )
    );
  };

  // Handle updating font family
  const handleFontFamilyChange = (newFontFamily) => {
    setFontFamily(newFontFamily);
    setFontWeight(fontFamilies[newFontFamily][0]);  // Reset font weight to the first available one
    setElements((prevElements) =>
      prevElements.map((el) =>
        el.id === selectedId && el.type === 'text'
          ? { ...el, fontFamily: newFontFamily, fontWeight: fontFamilies[newFontFamily][0] }
          : el
      )
    );
  };

  // Handle updating font weight
  const handleFontWeightChange = (newFontWeight) => {
    setFontWeight(newFontWeight);
    setElements((prevElements) =>
      prevElements.map((el) =>
        el.id === selectedId && el.type === 'text'
          ? { ...el, fontWeight: newFontWeight, fontFamily: fontFamily }  // Correct usage of fontFamily
          : el
      )
    );
  };

  // Handle updating text color
  const handleTextColorChange = (e) => {
    const newColor = e.target.value;
    setTextColor(newColor);
    setElements((prevElements) =>
      prevElements.map((el) =>
        el.id === selectedId && el.type === 'text'
          ? { ...el, fill: newColor }
          : el
      )
    );
  };

  // Handle deleting selected element
  const handleDelete = useCallback(() => {
    if (selectedId) {
      setElements((prevElements) =>
        prevElements.filter((el) => el.id !== selectedId)
      );
      setSelectedId(null);
    }
  }, [selectedId]);

  // Handle keyboard shortcuts (Delete/Backspace) only when not editing text
  useEffect(() => {
    const handleKeyPress = (e) => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && !isEditingText) {
        handleDelete();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [handleDelete, isEditingText]);

  // Handle clearing/resetting the canvas
  const handleResetCanvas = () => {
    setElements([]);
    setSelectedId(null);
  };

  // Handle exporting the canvas design as an image
  const handleExport = () => {
    const uri = stageRef.current.toDataURL({ pixelRatio: 2 });
    const link = document.createElement('a');
    link.href = uri;
    link.download = 'canvas-design.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Attach Transformer to the selected node
  useEffect(() => {
    if (selectedId && transformerRef.current) {
      const stage = stageRef.current;
      const selectedNode = stage.findOne(`.${selectedId}`);
      if (selectedNode) {
        transformerRef.current.nodes([selectedNode]);
        transformerRef.current.getLayer().batchDraw();
      }
    } else {
      transformerRef.current?.nodes([]);
    }
  }, [selectedId]);

  return (
    <Container fluid>
      <Row className="mt-4 justify-content-center">
        <Col lg={3} className="border border-2 rounded-3">
          <h1>Canvas Settings</h1>
          <Button onClick={handleAddText} className="mb-3" variant="primary">
            Add Text
          </Button>
          <ImageUpload onImageAdd={handleAddImage} />
          <div className="mt-3 d-flex justify-content-between">
            <Button variant="danger" onClick={handleResetCanvas}>
              Reset Canvas
            </Button>
            <Button variant="success" onClick={handleExport}>
              Download Canvas
            </Button>
          </div>

          {selectedId && elements.find((el) => el.id === selectedId)?.type === 'text' && (
            <>
              <Form.Group className="mt-3">
                <Form.Label>Select Heading</Form.Label>
                <Form.Control
                  as="select"
                  onChange={(e) => handleFontSizeChange(parseInt(e.target.value))}
                >
                  {Object.keys(headingFontSizes).map((heading) => (
                    <option key={heading} value={headingFontSizes[heading]}>
                      {heading}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>

              <Form.Group className="mt-3">
                <Form.Label>Select Font Family</Form.Label>
                <Form.Control
                  as="select"
                  value={fontFamily}
                  onChange={(e) => handleFontFamilyChange(e.target.value)}
                >
                  {Object.keys(fontFamilies).map((family) => (
                    <option key={family} value={family}>
                      {family}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>

              <Form.Group className="mt-3">
                <Form.Label>Select Font Weight</Form.Label>
                <Form.Control
                  as="select"
                  value={fontWeight}
                  onChange={(e) => handleFontWeightChange(e.target.value)}
                >
                  {fontFamilies[fontFamily].map((weight) => (
                    <option key={weight} value={weight}>
                      {weight}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>

              <Form.Group className="mt-3">
                <Form.Label>Edit Text</Form.Label>
                <Form.Control
                  type="text"
                  value={textEdit}
                  onFocus={() => setIsEditingText(true)}
                  onBlur={() => setIsEditingText(false)}
                  onChange={handleTextEdit}
                />
              </Form.Group>

              <Form.Group className="mt-3">
                <Form.Label>Text Color</Form.Label>
                <Form.Control
                  type="color"
                  value={textColor}
                  onChange={handleTextColorChange}
                />
              </Form.Group>
            </>
          )}
        </Col>

        <Col lg={5}>
          <div className="canvas-container border border-2 rounded-3" style={{ height: '700px', width: '' }}>
          <Stage
              ref={stageRef}
              width={570}
              height={700}
              onMouseDown={(e) => {
                // Deselect if clicked on empty area (Stage itself)
                if (e.target === e.target.getStage()) {
                  setSelectedId(null);
                }
              }}
            >
              <Layer>
                {elements.map((el, i) => {
                  if (el.type === 'text') {
                    return (
                      <Text
                        key={i}
                        name={el.id}
                        className={el.id}
                        x={el.x}
                        y={el.y}
                        text={el.text}
                        fontSize={el.fontSize}
                        fontFamily={el.fontFamily}
                        fontWeight={el.fontWeight}
                        fill={el.fill}
                        draggable={el.draggable}
                        onClick={handleSelect}
                        onTap={handleSelect}
                        dragBoundFunc={(pos) => {
                          return {
                            x: Math.max(0, Math.min(pos.x, 570 - 100)), // restricts dragging within canvas
                            y: Math.max(0, Math.min(pos.y, 700 - 30)),  // restricts dragging within canvas
                          };
                        }}
                      />
                    );
                  } else if (el.type === 'image') {
                    return (
                      <DynamicImage
                        key={i}
                        name={el.id}
                        className={el.id}
                        src={el.src}
                        x={el.x}
                        y={el.y}
                        draggable
                        onClick={handleSelect}
                        onTap={handleSelect}
                        dragBoundFunc={(pos) => {
                          return {
                            x: Math.max(0, Math.min(pos.x, 570 - 150)),
                            y: Math.max(0, Math.min(pos.y, 700 - 150)),
                          };
                        }}
                      />
                    );
                  }
                  return null;
                })}

                <Transformer ref={transformerRef} />
              </Layer>
            </Stage>
          </div>
        </Col>

        <Col lg={3} className="border border-2 rounded-3">
          <h4>Select an Image</h4>
          <Row>
          {galleryImages.map((imageUrl, index) => (
            <Col sm={4} xs={3} key={index} className="mb-3">
              <Image
                src={imageUrl}
                fluid
                style={{ cursor: 'pointer' }}
                onClick={() => handleAddImage(imageUrl)}
              ></Image>
            </Col>
          ))}
          </Row>
        </Col>
      </Row>
    </Container>
  );
};

// Dynamic Image Component
const DynamicImage = ({ src, ...props }) => {
  const [image] = useImage(src);
  return <KonvaImage image={image} {...props} />;
};

export default CanvasApp;