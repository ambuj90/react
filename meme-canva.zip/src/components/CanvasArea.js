import React, { useRef, useEffect } from 'react';
import { Stage, Layer, Text, Transformer } from 'react-konva';
import DynamicImage from './DynamicImage';

const CanvasArea = ({
  elements,
  selectedId,
  handleSelect,
  transformerRef,
  stageRef,
  width = 600,
  height = 700,
}) => {
  useEffect(() => {
    if (selectedId && transformerRef.current) {
      const stage = stageRef.current;
      const selectedNode = stage.findOne(`.${selectedId}`);
      if (selectedNode) {
        transformerRef.current.nodes([selectedNode]);
        transformerRef.current.getLayer().batchDraw();
      }
    } else {
      transformerRef.current?.nodes([]);
    }
  }, [selectedId, transformerRef]);

  return (
    <div className="canvas-container border border-2 rounded-3" style={{ height: `${height}px`, width: `${width}px` }}>
      <Stage ref={stageRef} width={width} height={height}>
        <Layer>
          {elements.map((el, i) => {
            if (el.type === 'text') {
              return (
                <Text
                  key={i}
                  name={el.id}
                  className={el.id}
                  x={el.x}
                  y={el.y}
                  text={el.text}
                  fontSize={el.fontSize}
                  fontFamily={el.fontFamily}
                  fontWeight={el.fontWeight}
                  fill={el.fill}
                  draggable={el.draggable}
                  onClick={handleSelect}
                  onTap={handleSelect}
                  dragBoundFunc={(pos) => ({
                    x: Math.max(0, Math.min(pos.x, width - 100)),
                    y: Math.max(0, Math.min(pos.y, height - 30)),
                  })}
                />
              );
            } else if (el.type === 'image') {
              return (
                <DynamicImage
                  key={i}
                  name={el.id}
                  className={el.id}
                  src={el.src}
                  x={el.x}
                  y={el.y}
                  draggable
                  onClick={handleSelect}
                  onTap={handleSelect}
                  dragBoundFunc={(pos) => ({
                    x: Math.max(0, Math.min(pos.x, width - 150)),
                    y: Math.max(0, Math.min(pos.y, height - 150)),
                  })}
                />
              );
            }
            return null;
          })}

          <Transformer ref={transformerRef} />
        </Layer>
      </Stage>
    </div>
  );
};

export default CanvasArea;