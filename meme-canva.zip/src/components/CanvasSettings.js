import React from 'react';
import { Button, Form } from 'react-bootstrap';
import ImageUpload from './ImageUpload';

const CanvasSettings = ({
  handleAddText,
  handleAddImage,
  handleResetCanvas,
  handleExport,
  selectedId,
  elements,
  fontSize,
  fontFamily,
  fontWeight,
  textEdit,
  textColor,
  handleFontSizeChange,
  handleFontFamilyChange,
  handleFontWeightChange,
  handleTextEdit,
  handleTextColorChange,
  headingFontSizes,
  fontFamilies,
  setIsEditingText  // Add this line
}) => {
  return (
    <>
      <h1 className='mb-2'>Design Memes</h1>
      <Button onClick={handleAddText} className="mb-3" variant="primary">
        Add Text(Multiple)
      </Button>
      <ImageUpload onImageAdd={handleAddImage} />
      <div className="mt-3 d-flex justify-content-between">
        <Button variant="danger" onClick={handleResetCanvas}>
          Reset Design
        </Button>
        <Button variant="success" onClick={handleExport}>
          Download Meme
        </Button>
      </div>

      {selectedId && elements.find((el) => el.id === selectedId)?.type === 'text' && (
        <>
          <Form.Group className="mt-3">
            <Form.Label>Select Heading</Form.Label>
            <Form.Control
              as="select"
              onChange={(e) => handleFontSizeChange(parseInt(e.target.value))}
            >
              {Object.keys(headingFontSizes).map((heading) => (
                <option key={heading} value={headingFontSizes[heading]}>
                  {heading}
                </option>
              ))}
            </Form.Control>
          </Form.Group>

          <Form.Group className="mt-3">
            <Form.Label>Select Font Family</Form.Label>
            <Form.Control
              as="select"
              value={fontFamily}
              onChange={(e) => handleFontFamilyChange(e.target.value)}
            >
              {Object.keys(fontFamilies).map((family) => (
                <option key={family} value={family}>
                  {family}
                </option>
              ))}
            </Form.Control>
          </Form.Group>

          <Form.Group className="mt-3">
            <Form.Label>Select Font Weight</Form.Label>
            <Form.Control
              as="select"
              value={fontWeight}
              onChange={(e) => handleFontWeightChange(e.target.value)}
            >
              {fontFamilies[fontFamily].map((weight) => (
                <option key={weight} value={weight}>
                  {weight}
                </option>
              ))}
            </Form.Control>
          </Form.Group>

          <Form.Group className="mt-3">
            <Form.Label>Edit Text</Form.Label>
            <Form.Control
              type="text"
              value={textEdit}
              onFocus={() => setIsEditingText(true)}  // Use setIsEditingText here
              onBlur={() => setIsEditingText(false)}  // Use setIsEditingText here
              onChange={handleTextEdit}
            />
          </Form.Group>

          <Form.Group className="mt-3">
            <Form.Label>Text Color</Form.Label>
            <Form.Control
              type="color"
              value={textColor}
              onChange={handleTextColorChange}
            />
          </Form.Group>
        </>
      )}
    </>
  );
};

export default CanvasSettings;