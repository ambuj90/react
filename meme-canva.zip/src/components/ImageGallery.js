import React from 'react';
import { Image, Col, Row } from 'react-bootstrap';


const ImageGallery = ({ galleryImages, handleAddImage }) => {
  return (
    <Row>
      {galleryImages.map((imageUrl, index) => (
        <Col xs={6} md={4} key={index} className="mb-3">
          <Image
            src={imageUrl}
            fluid
            style={{ cursor: 'pointer' }}
            onClick={() => handleAddImage(imageUrl)}
          />
        </Col>
      ))}
      <Col lg={3} className="border border-2 rounded-3">
          <h4>Select an Image</h4>
          <ImageGallery galleryImages={galleryImages} handleAddImage={handleAddImage} />
        </Col>
    </Row>

    
  );
};

export default ImageGallery;