import React from 'react';
import { Form } from 'react-bootstrap';

const ImageUpload = ({ onImageAdd }) => {
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      onImageAdd(reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <Form.Group controlId="formFile" className="mb-3">
      <Form.Label>Upload Image</Form.Label>
      <Form.Control type="file" accept="image/*" onChange={handleFileChange} />
    </Form.Group>
  );
};

export default ImageUpload;