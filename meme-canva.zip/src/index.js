import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import CanvasApp from './App';

ReactDOM.render(
  <React.StrictMode>
    <CanvasApp />
  </React.StrictMode>,
  document.getElementById('root')
);